#!/usr/bin/perl

$inputfile = "killfile";
$burstnumber = 2;
$numprocs = $ARGV[0];
$numtokens = $ARGV[1];
$hostfile = $ARGV[2];
$killprocs = $numprocs - 2;
#$killprocs = 0;

if ($#ARGV != 2) {
    print "Usage: ./tester.pl <numprocs> <numtokens> <hostfile>\n";
    exit 1;
}

system("rm -rf even-epochs burst-epochs major-epochs critical-epochs");

#Kill evenly

print "KILL EVENLY\n";

%deadprocs = ();
$deadprocs{0} = 1;

open(KILLFILE , ">$inputfile");

print KILLFILE "$killprocs\n";

for ($i = 0; $i < $killprocs; $i++) {
    do {
        $randproc = int(rand($numprocs - 1));
        $randproc = $i+1;
    } while ($deadprocs{$randproc});
    
    $deadprocs{$randproc} = 1;

    print KILLFILE "$randproc " . ($i + 1) * (100 / ($killprocs + 1)) . "\n";
}

close(KILLFILE);

print "Distribute kill file\n";
system("./distribute-kill-file $hostfile $numprocs $inputfile >/dev/null");
print "Run benchmark (output in even.out)\n";
system("mpirun --np $numprocs --hostfile $hostfile -bynode -x LD_LIBRARY_PATH ./ring $numprocs $numtokens $inputfile > even.out");
system("mkdir even-epochs");
system("./cleanup");
system("./gather-epoch-files $hostfile $numprocs even-epochs > /dev/null");
system("./delete-epoch-files");
#system("mpirun --np $numprocs --hostfile $hostfile -bynode ring $numprocs $numtokens $inputfile > even_out");
exit 0;
#Kill in bursts

print "KILL BURST\n";

%deadprocs = ();
$deadprocs{0} = 1;

open(KILLFILE , ">$inputfile");

print KILLFILE "$killprocs\n";

for ($i = 0; $i < $killprocs / $burstnumber; $i++) {
    for ($j = 0; $j < $burstnumber; $j++) {
        do {
            $randproc = int(rand($numprocs - 1));
        } while ($deadprocs{$randproc});

        $deadprocs{$randproc} = 1;

        print KILLFILE "$randproc " . ($i + 1) * (100 / (($killprocs / $burstnumber) + 1)) . "\n";
    }
}

close(KILLFILE);


print "Distribute kill file\n";
system("./distribute-kill-file $hostfile $numprocs $inputfile >/dev/null");
print "Run benchmark (output in burst.out)\n";
system("mpirun --np $numprocs --hostfile $hostfile -bynode -x LD_LIBRARY_PATH ./ring $numprocs $numtokens $inputfile > burst.out");
system("mkdir burst-epochs");
system("./cleanup");
system("./gather-epoch-files $hostfile $numprocs burst-epochs > /dev/null");
system("./delete-epoch-files");
#system("mpirun --np $numprocs --hostfile $hostfile -bynode ring $numprocs $numtokens $inputfile > burst.out");

#Kill half in middle

print "KILL MAJOR\n";

%deadprocs = ();
$deadprocs{0} = 1;
$burstnumber = int($numprocs / 2);

open(KILLFILE , ">$inputfile");

print KILLFILE "$killprocs\n";

for ($i = 0; $i < int($killprocs / $burstnumber); $i++) {
    for ($j = 0; $j < $burstnumber; $j++) {
        do {
            $randproc = int(rand($numprocs - 1));
        } while ($deadprocs{$randproc});

        $deadprocs{$randproc} = 1;

        print KILLFILE "$randproc " . ($i + 1) * (100 / (int($killprocs / $burstnumber) + 1)) . "\n";
    }
}

close(KILLFILE);

print "Distribute kill file\n";
system("./distribute-kill-file $hostfile $numprocs $inputfile >/dev/null");
print "Run benchmark (output in major.out)\n";
system("mpirun --np $numprocs --hostfile $hostfile -bynode -x LD_LIBRARY_PATH ./ring $numprocs $numtokens $inputfile > major.out");
system("mkdir major-epochs");
system("./cleanup");
system("./gather-epoch-files $hostfile $numprocs major-epochs > /dev/null");
system("./delete-epoch-files");

#Kill n-2 in middle

print "KILL CRITICAL\n";

%deadprocs = ();
$deadprocs{0} = 1;
$burstnumber = $numprocs - 2;

open(KILLFILE , ">$inputfile");

print KILLFILE "$killprocs\n";

for ($i = 0; $i < int($killprocs / $burstnumber); $i++) {
    for ($j = 0; $j < $burstnumber; $j++) {
        do {
            $randproc = int(rand($numprocs - 1));
        } while ($deadprocs{$randproc});

        $deadprocs{$randproc} = 1;

        print KILLFILE "$randproc " . ($i + 1) * (100 / (int($killprocs / $burstnumber) + 1)) . "\n";
    }
}

close(KILLFILE);

print "Distribute kill file\n";
system("./distribute-kill-file $hostfile $numprocs $inputfile >/dev/null");
print "Run benchmark (output in critical.out)\n";
system("mpirun --np $numprocs --hostfile $hostfile -bynode -x LD_LIBRARY_PATH ./ring $numprocs $numtokens $inputfile > critical.out");
system("mkdir critical-epochs");
system("./cleanup");
system("./gather-epoch-files $hostfile $numprocs critical-epochs > /dev/null");
system("./delete-epoch-files");
