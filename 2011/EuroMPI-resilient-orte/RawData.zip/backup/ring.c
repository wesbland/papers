#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>

#include "orte/runtime/runtime.h"
#include "orte/runtime/orte_wait.h"
#include "orte/mca/rml/rml.h"
#include "orte/mca/rml/rml_types.h"
#include "orte/util/proc_info.h"
#include "orte/util/name_fns.h"
#include "orte/mca/errmgr/errmgr.h"
#include "orte/runtime/orte_globals.h"
#include "orte/mca/errmgr/errmgr.h"

#define TAG 31337
#define DELAY 1000
#define KILLTIME 30

typedef struct token {
    int sequence_num;
    int epoch;
    suseconds_t start_time;
    suseconds_t stop_time;
    int num_hops;
} token_t;

bool *alive;
int num_dead = 0, num_procs, num_tokens, next_token;
token_t *tokens;
bool root;
int go;
int last_token = 0;
int next_dead = 0;
int rc = 0;
suseconds_t *epochs;
struct timeval time_of_day;

void root_recv_callback(int status,
        struct orte_process_name_t *peer,
        struct iovec *msg,
        int count,
        orte_rml_tag_t tag,
        void *cbdata) {
    token_t cur_token;
    struct timeval time_of_day;

    assert(msg->iov_len == sizeof(token_t));

    memcpy(&cur_token, msg->iov_base, sizeof(token_t));

    gettimeofday(&time_of_day, NULL);
    cur_token.stop_time = (1000000 * time_of_day.tv_sec) + time_of_day.tv_usec;

    memcpy(&tokens[cur_token.sequence_num], &cur_token, sizeof(token_t));

    last_token = cur_token.sequence_num;
#if 0
    fprintf(stderr, "LAST TOKEN: %d\n", last_token);
#endif
}

void print_epoch_values() {
    int i;
    char filename[1024];
    sprintf(filename, "epochs-%d.out", ORTE_PROC_MY_NAME->vpid);
    FILE *epoch_file = fopen(filename, "w");

    for (i = 0; i < num_procs; i++) {
        fprintf(epoch_file, "%d %ld\n", i, (epochs[i] - epochs[0]));
    }

    fclose(epoch_file);
}

void stopping() {
    int i;

    if (root) {
        for (i = 0; i < num_tokens; i++ ) {
            fprintf(stdout, "%d,%d,%d,%d\n",
                    tokens[i].sequence_num,
                    tokens[i].epoch,
                    (int) (tokens[i].stop_time - tokens[i].start_time),
                    tokens[i].num_hops);

        }
    }
    
    print_epoch_values();

    orte_finalize();

    exit(rc);
}

void wakeup() {
    go = 1;
}

void fail(orte_process_name_t *proc) {
    if (ORTE_PROC_MY_NAME->jobid != proc->jobid) {
        return;
    }

#if 0   
    if (root) {
    fprintf(stderr, "%s FAULT DETECTED %s\n", 
            ORTE_NAME_PRINT(ORTE_PROC_MY_NAME),
            ORTE_NAME_PRINT(proc));
    }
#endif 

    alive[proc->vpid] = false;
    num_dead++;
    
    gettimeofday(&time_of_day, NULL);
    epochs[num_dead] = (1000000 * time_of_day.tv_sec) + time_of_day.tv_usec;
}

int main(int argc, char **argv) {
    struct iovec msg, *recv_msg;
    int i, expected_failures, *failure_list, *death_message;
    token_t *cur_token;
    orte_process_name_t dest;
    FILE *failure_file;
    float percent;

    gettimeofday(&time_of_day, NULL);

    srand((unsigned int) time_of_day.tv_usec);
    
    if (argc != 4) {
        fprintf(stderr, "Not enough arguments, format: ring <num_procs> <num_tokens> <failure_file>\n");
        return 1;
    }

    num_procs = strtol(argv[1], NULL, 10);
    num_tokens = strtol(argv[2], NULL, 10);

    alive = (bool *) malloc(num_procs * sizeof(bool));
    epochs = (suseconds_t *) malloc(num_procs * sizeof(suseconds_t));

    gettimeofday(&time_of_day, NULL);
    for (i = 0; i < num_procs; i++) {
        alive[i] = true;
        epochs[i] = (1000000 * time_of_day.tv_sec) + time_of_day.tv_usec;
    }

    orte_init(&argc, &argv, ORTE_PROC_NON_MPI);

    orte_errmgr.set_fault_callback(*fail);

    root = (0 == ORTE_PROC_MY_NAME->vpid);

    if (root) {
        tokens = (token_t *) malloc(num_tokens * sizeof(token_t ));
        /*fprintf(stdout, "NUM_PROCS: %d\tNUM_TOKENS: %d\n", num_procs, num_tokens);*/

        for (i = 0; i < num_tokens; i++) {
            tokens[i].sequence_num = i;
            tokens[i].epoch = -1;
            tokens[i].start_time = -1;
            tokens[i].stop_time = -1;
            tokens[i].num_hops = -1;
        }
    }
    
    dest.jobid = ORTE_PROC_MY_NAME->jobid;
    dest.epoch = 0;

    dest.vpid = ORTE_PROC_MY_NAME->vpid + 1;
    if (dest.vpid == num_procs) {
        dest.vpid = 0;
    }

    if (root) {
        recv_msg = (struct iovec *) malloc(sizeof(struct iovec));
        recv_msg->iov_base = (void *) malloc(sizeof(token_t));
        recv_msg->iov_len = sizeof(token_t);
        orte_rml.recv_nb(ORTE_NAME_WILDCARD,
                recv_msg,
                1,
                TAG,
                ORTE_RML_PERSISTENT,
                root_recv_callback,
                NULL);
    } else {
        /* Read the input file */
        failure_file = fopen(argv[3], "r");
        fscanf(failure_file, "%d", &expected_failures);
        
        failure_list = (int *) malloc(expected_failures * sizeof(int));
        death_message = (int *) malloc(expected_failures * sizeof(int));

        for (i = 0; i < expected_failures; i++) {
            fscanf(failure_file, "%d %f", &failure_list[i], &percent);
            death_message[i] = (int) (num_tokens * (percent / 100.0));
        }
    }
        
    ORTE_TIMER_EVENT(KILLTIME, 0, *stopping);

    /* Root starts the tokens */
    for (i = 0; i < num_tokens && root; i++) {
        go = 0;
        ORTE_TIMER_EVENT(0, DELAY, *wakeup);
        ORTE_PROGRESSED_WAIT(0, go, 1);

        cur_token = (token_t *) malloc(sizeof(token_t));
        msg.iov_base = (void *) cur_token;
        msg.iov_len = sizeof(token_t);

        /* Start a new token */
        cur_token->sequence_num = i;
        cur_token->epoch = num_dead;
        gettimeofday(&time_of_day, NULL);
        cur_token->start_time = (1000000 * time_of_day.tv_sec) + time_of_day.tv_usec;
        cur_token->stop_time = 0;
        cur_token->num_hops = 0;

        /* Check the destination */
        while (!alive[dest.vpid] && dest.vpid < num_procs) {
            dest.vpid++;
        }

        /* Send the new token */
        orte_rml.send(&dest, &msg, 1, TAG, 0);
    }

    if (!root) {
        cur_token = (token_t *) malloc(sizeof(token_t));
        do {
            msg.iov_base = (void *) cur_token;
            msg.iov_len = sizeof(token_t);

            orte_rml.recv(ORTE_NAME_WILDCARD, &msg, 1, TAG, 0);

            cur_token = msg.iov_base;

            if (cur_token->sequence_num >= death_message[next_dead]) {
                do {
                    if (ORTE_PROC_MY_NAME->vpid == failure_list[next_dead]) {
                        system("killall orted");
                        
                        gettimeofday(&time_of_day, NULL);
                        epochs[++num_dead] = (1000000 * time_of_day.tv_sec) + time_of_day.tv_usec;
                        print_epoch_values();

                        exit(0);
                    } else {
                        next_dead++;
                    }
                } while (cur_token->sequence_num >= death_message[next_dead]);
            }

            cur_token->num_hops++;

            /* Check the destination */
            while (!alive[dest.vpid] && dest.vpid < num_procs) {
                dest.vpid++;
            }

            if (dest.vpid == num_procs) {
                dest.vpid = 0;
            }

            /*fprintf(stderr, "%s DEST: %s\n",
                    ORTE_NAME_PRINT(ORTE_PROC_MY_NAME),
                    ORTE_NAME_PRINT(&dest));*/
            while (0 > orte_rml.send(&dest, &msg, 1, TAG, 0)) {
                dest.vpid++;
            
                if (dest.vpid == num_procs) {
                    dest.vpid = 0;
                }
            }

            if (num_tokens - 1 == cur_token->sequence_num) {
                break;
            }
        } while(num_tokens - 1 > cur_token->sequence_num);
    } else {
        ORTE_PROGRESSED_WAIT(0, last_token + 1, num_tokens);
    }

    stopping();

    return rc;
}
