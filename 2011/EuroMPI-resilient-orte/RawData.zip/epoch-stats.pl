#!/usr/bin/perl

use Data::Dumper;

if ($#ARGV != 0) {
    print "Usage: ./epoch-stats.pl <epochfolder>\n";
    exit 1;
}

$epochfolder = $ARGV[0];

opendir my $dh, $epochfolder or die "Can't open $epochfolder: $!";
@files = map {"$epochfolder/$_"} grep { $_ !~ /^\./ } readdir $dh;

for ($i = 0; $i < scalar(@files); $i++) {
    open(FILE, "$epochfolder/epochs-$i.out");

    while (<FILE>) {
        chomp;
        if ('#' != substr($_, 0, 1)) {
            ($epochnum, $time) = split(/ /, $_);
            push @{$epochs[$epochnum]}, $time;
        }
    }

    close(FILE);
}

for ($i = 0; $i < scalar(@files); $i++) {
    print "$i ";
    for ($j = 0; $j < scalar(@files); $j++) {
        print "$epochs[$j][$i]\t";
    }
    print "\n";
}
