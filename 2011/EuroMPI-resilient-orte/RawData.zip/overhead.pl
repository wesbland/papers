#!/usr/bin/perl

use Data::Dumper;

$faults = "peta.out";
$ff = "ff.out";

open(FAULT, $faults);
open(FF, $ff);

@fault_input = <FAULT>;
@ff_input = <FF>;

chomp @fault_input;
chomp @ff_input;

print "1\n";
print "size " . $#fault_input . "\n";
print "2\n";

for ($i = 0; $i <= $#fault_input; $i++) {
    @val1 = split(/,/, $fault_input[$i]);
    @val2 = split(/,/, $ff_input[$i]);
    $total[$i] = ($val1[2] - $val2[2]) / 1000;
}

foreach $val (@total) {
    print "$val\n";
}
